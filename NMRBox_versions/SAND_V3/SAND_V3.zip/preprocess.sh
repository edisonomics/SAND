#!/bin/bash
ORIGIN=$(pwd)
# preprocess V1: 05-10-2022 OS
echo "$ORIGIN"
export TDD=$ORIGIN/NMR_time_domain_decomposition 
export ELSM=$ORIGIN/Edison_Lab_Shared_Metabolomics_UGA
export NCPUS=$(nproc)
export WDIR=$ORIGIN #'/home/nmrbox/osanati/tda'

echo "Preprocessing (PID=$$) started"

time /usr/software/MATLAB/R2021b/bin/matlab < ./preprocessv1.m > ./log/preprocess$$.log 2> ./log/preprocess$$.err
#-nojvm -nosplash -nodisplay  > tda$$.log 2>tda$$.err
