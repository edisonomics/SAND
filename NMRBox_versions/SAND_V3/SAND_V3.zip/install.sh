#install V3 6-18-2022 OS
git clone https://github.com/mikeaalv/NMR_time_domain_decomposition.git
git clone https://github.com/artedison/Edison_Lab_Shared_Metabolomics_UGA.git
mkdir data temp log submissions
chmod a+rwx ./preprocess.sh
chmod a+rwx ./processV3.sh
chmod a+rwx ./submitprocessV3.sh

