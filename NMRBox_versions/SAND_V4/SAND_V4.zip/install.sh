#install V4 6-30-2022 OS
svn export https://github.com/edisonomics/SAND/trunk/scripts/NMRBox/pipe_scripts
svn export https://github.com/edisonomics/SAND/trunk/src
git clone https://github.com/artedison/Edison_Lab_Shared_Metabolomics_UGA.git
mkdir data temp log submissions
chmod a+rwx ./preprocessV4.sh
chmod a+rwx ./processV4.sh
chmod a+rwx ./submitprocessV4.sh
chmod a+rwx ./pipe_scripts/*

