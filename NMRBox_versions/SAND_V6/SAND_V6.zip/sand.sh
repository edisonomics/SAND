#!/bin/bash
ORIGIN=$(pwd)
# process SAND V6: 08-02-2022 OS
echo "$ORIGIN"
export TDD=$ORIGIN/src 
export ELSM=$ORIGIN/Edison_Lab_Shared_Metabolomics_UGA
export NCPUS=$(nproc)
export WDIR=$ORIGIN 
export TEMPDIR=$ORIGIN/temp
export LOGDIR=$ORIGIN/log
export NSAMPLE=1
export NSIG=7  #max number of peaks in each bin
export NTRY=2000 #number of iteration 
export TEMP=80 #temparature in MCMC

in1=0
in2=0
cluster=0
name=0
h1=0
while getopts a:b:c:y:s:i:t:z:h flag
do
    case "${flag}" in
        a) in1=${OPTARG};;	#a; low
        b) in2=${OPTARG};;	#b; high
        c) cluster=${OPTARG};;	#c; cluster or not
        y) name=${OPTARG};;	#y; name of job
        s) NSIG=${OPTARG};;
        i) NTRY=${OPTARG};;
        t) TEMP=${OPTARG};;
        z) NCPUS=${OPTARG};;
        h) h1=1;;
    esac
done

if (( $h1 == 1 )); then
	echo "this command performs SAND on the preprocessed data"
	echo "it has following options"
	echo "  -y: you must assign a unique name to each run of SAND"
	echo "  -a and -b: you can define which experiments (adjusted numbers) to run SAND on them"
	echo "  -z: number of cores to run each experiment"
	echo "  -s: maximum number of signals (after the deconvolution process) in each bin"
	echo "  -i: number of iterations in the MCMC (deconvolution process)"
	echo "  -t: temperature in  the MCMC (deconvolution process)"
	echo "default values:"
	echo "  -z (total number of physical cores)"
	echo "  -a 1 -b (total number of preprocessed folders)"
	echo "  -s 7"
	echo "  -i 2000"
	echo "  -t 80"
	exit 1
fi

count=($(ls -d ./res/nmrpipe_dir/*/))
export JOBNAME=${name}

t=${#count[*]}
((t += -1)) #length of all preprocessed data under ./res/nmrpipe_dir/
#echo $t
if (( $in1 == 0 && $in2 == 0 )); then
in1=1
in2=$t
elif (( $in1 > $t || $in2 > $t || $in1 < 1 )); then
	echo "try again! wrong experiment number!"
	exit 1
fi

if [[ ${cluster} == 0 ]]; then
	if [[ ${name} == 0 ]]; then
		echo "try again! wrong inputs: choose the name correctly!"
		exit 1
	fi

	allnames=$(ls ./log)
	for i in ${allnames}
	 do
		if [[ ${name} == $i ]]; then
			echo "try again! Job name already exists, choose different name correctly!"
			exit 1
		fi
	 done
	 
	 rm -rf log/${name}
	mkdir ./log/${name}
	mkdir ./log/${name}/results 
	 
fi



NSAMPLE=$in1   


echo "time-domain analysis (process name= ${name}) started on $NCPUS threads"
echo "for experiment(s) $in1 up to $in2."

while [ $NSAMPLE -ge $in1 ] && [ $NSAMPLE -le $in2 ]
do
	echo "experiment:$NSAMPLE started"
	time /usr/software/MATLAB/R2022a/bin/matlab < ./sand.m > $LOGDIR/${name}/process${name}.log 2> $LOGDIR/${name}/process${name}.err
	echo "experiment:$NSAMPLE finished"
	((NSAMPLE += 1))
done
