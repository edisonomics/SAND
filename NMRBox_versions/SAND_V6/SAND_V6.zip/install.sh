#install SAND V6 08-02-2022 OS
svn export https://github.com/edisonomics/SAND/trunk/scripts/NMRBox/pipe_scripts
svn export https://github.com/edisonomics/SAND/trunk/src
git clone https://github.com/artedison/Edison_Lab_Shared_Metabolomics_UGA.git
mkdir data temp log submissions data_preprocessed
chmod a+rwx ./preprocess.sh
chmod a+rwx ./sand.sh
chmod a+rwx ./submitsand.sh
chmod a+rwx ./pipe_scripts/*

