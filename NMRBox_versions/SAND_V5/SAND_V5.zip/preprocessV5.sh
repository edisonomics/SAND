#!/bin/bash
ORIGIN=$(pwd)
# preprocess V5: 07-05-2022 OS
echo "$ORIGIN"
export TDD=$ORIGIN/src 
export ELSM=$ORIGIN/Edison_Lab_Shared_Metabolomics_UGA
export NCPUS=$(nproc)
export WDIR=$ORIGIN
export PREP=0
export LPPM=-0.4
export UPPM=10 
export GBIN=3

while getopts p:l:u:g: flag
do
    case "${flag}" in
        p) PREP=${OPTARG};;	#p; already preprocessed(1) or not(0)
        l) LPPM=${OPTARG};;	#l; lowest ppm
        u) UPPM=${OPTARG};;	#c; highest ppm
        g) GBIN=${OPTARG};;	#g; number of bins to be grouped 
    esac
done

if (( $PREP != 0 && $PREP != 1 )); then
	echo "try again! wrong inputs: choose you preprocessed status by 1 or 0!"
	exit 1
fi

if [[ $LPPM > $UPPM ]]; then
	echo "try again! wrong inputs: choose lower/upper limit ppms correctly!"
	exit 1
fi
if [[ $GBIN < 1 ]]; then
	echo "try again! wrong inputs: choose number of bins in each group correctly!"
	exit 1
fi

echo "Preprocessing (PID=$$) started"

time /usr/software/MATLAB/R2021b/bin/matlab < ./preprocessV5.m > ./log/preprocess$$.log 2> ./log/preprocess$$.err
#-nojvm -nosplash -nodisplay  > tda$$.log 2>tda$$.err
