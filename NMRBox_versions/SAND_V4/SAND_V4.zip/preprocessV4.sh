#!/bin/bash
ORIGIN=$(pwd)
# preprocess V4: 06-30-2022 OS
echo "$ORIGIN"
export TDD=$ORIGIN/src 
export ELSM=$ORIGIN/Edison_Lab_Shared_Metabolomics_UGA
export NCPUS=$(nproc)
export WDIR=$ORIGIN 

echo "Preprocessing (PID=$$) started"

time /usr/software/MATLAB/R2021b/bin/matlab < ./preprocessV4.m > ./log/preprocess$$.log 2> ./log/preprocess$$.err
#-nojvm -nosplash -nodisplay  > tda$$.log 2>tda$$.err
