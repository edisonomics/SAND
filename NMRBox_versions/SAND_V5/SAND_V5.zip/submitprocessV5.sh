#!/bin/bash
#submitprocess V5 6-30-2022 OS

export NSIG=7  #max number of peaks in each bin
export NTRY=2000 #number of iteration 
export TEMP=80 #temperature in MCMC

in1=0
in2=0
cores=100
name=0
MASH=0
count=($(ls -d ./res/nmrpipe_dir/*/))
while getopts a:b:x:y:z:s:i:t: flag
do
    case "${flag}" in
        a) in1=${OPTARG};;	#a; low
        b) in2=${OPTARG};;	#b; high
        x) MASH=${OPTARG};;	#x; server to submit job
        y) name=${OPTARG};;	#y; name of job
        z) cores=${OPTARG};;	#z; number of cores
        s) NSIG=${OPTARG};;	#s; max number of peaks in each bin
        i) NTRY=${OPTARG};;	#i; number of iteration 
        t) TEMP=${OPTARG};;	#t; temparature in MCMC
    esac
done
t=${#count[*]}
((t += -1)) #length of all preprocessed data under ./res/nmrpipe_dir/
#echo t=$t
if (( $in1 == 0 && $in2 == 0 )); then
in1=1
in2=$t
elif (( $in1 > $t || $in2 > $t || $in1 < 1 )); then
	echo $in1 $in2 $t 
	echo "try again! wrong experiment number!"
	exit 1
fi

if [[ ${MASH} == 0 || ${name} == 0 ]]; then
	echo "try again! wrong inputs: choose servers and names correctly!"
	exit 1
fi

allnames=$(ls ./log)
for i in ${allnames}
 do
	if [[ ${name} == $i ]]; then
		echo "try again! Job name already exists, choose different name correctly!"
		exit 1
	fi
 done

#echo ${MASH}
allinput='all'

if [[ ${MASH} != ${allinput} ]]; then

#list of available servers
rm -rf log/${name}
mkdir ./log/${name}
mkdir ./log/${name}/condor/
mkdir ./log/${name}/results 
#MASH='babbage.nmrbox.org'

#create submission files

cat << EOF > ./submissions/${name}.sub
universe = vanilla
executable = $(pwd)/processV5.sh 
arguments = -a ${in1} -b ${in2} -s ${NSIG} -i ${NTRY} -t ${TEMP} -y ${name} -z ${cores} -c 1
request_memory = 20G
request_cpus = ${cores}
request_gpus = 0
getenv=True
requirements = (Machine==${MASH})
requirements = (Target.Production == True)
+Production = True
output = log/${name}/condor/${name}.stdout
error = log/${name}/condor/${name}.stderr
log = log/${name}/condor/${name}.log
notification = Error
# Rely on a shared filesystem
transfer_executable = FALSE
should_transfer_files = NO
#JobName = ${name}
queue
EOF


#submit the job

condor_submit ./submissions/${name}.sub
echo "Job '${name}' :experiment(s) $in1 to $in2."
echo "It is submitted to '${MASH}' with ${cores} cores." 
echo "Check the status with 'condor_q'"

fi

if [[ ${MASH} == ${allinput} ]]; then    ####### ALL MACHINES

name2=1
name2=(${name}${name2})
allnames=$(ls ./log)
for i in ${allnames}
 do
	if [[ ${name2} == $i ]]; then
		echo "try again! Job name already exists, choose different name correctly!"
		exit 1
	fi
 done

(( in1_2 = ${in1} ))
(( len = $in2 - $in1 ))
(( len += 1 ))
i=0
for i in $(seq 1 1 $len)   
do

#list of available servers
#MASH='Machine=='babbage.nmrbox.org' || Machine=='germanium.nmrbox.org' || Machine=='manganese.nmrbox.org' || Machine=='nickel.nmrbox.org' || Machine=='magnesium.nmrbox.org' || Machine=='arsenic.nmrbox.org' || Machine=='tin.nmrbox.org' || Machine=='chromium.nmrbox.org' || Machine=='barium.nmrbox.org' || Machine=='cadmium.nmrbox.org'|| Machine=='silicon.nmrbox.org' || Machine=='bromine.nmrbox.org' ||Machine=='indium.nmrbox.org'|| Machine=='calcium.nmrbox.org' || Machine=='fluorine.nmrbox.org' || Machine=='scandium.nmrbox.org'|| Machine=='palladium.nmrbox.org''

name_a=(${name}${i})
rm -rf log/${name_a}
mkdir ./log/${name_a}
mkdir ./log/${name_a}/condor/
mkdir ./log/${name_a}/results 
#create submission files
cat << EOF > ./submissions/${name_a}.sub
universe = vanilla
executable = $(pwd)/processV5.sh 
arguments = -a ${in1_2} -b ${in1_2} -s ${NSIG} -i ${NTRY} -t ${TEMP} -y ${name_a} -z ${cores} -c 1
request_memory = 20G
request_cpus = ${cores}
request_gpus = 0
getenv=True
requirements = ((Target.Release == "2022.21") ||  (Target.Release == "2022.19") || (Target.Release == "2022.16") || (Target.Release == "2022.15")) 
#requirements = (Target.Production == True)
+Production = True
output = log/${name_a}/condor/${name_a}.stdout
error = log/${name_a}/condor/${name_a}.stderr
log = log/${name_a}/condor/${name_a}.log
notification = Error
# Rely on a shared filesystem
transfer_executable = FALSE
should_transfer_files = NO
#JobName = ${name_a}
queue
EOF


#submit the job

condor_submit ./submissions/${name_a}.sub
echo "Job '${name_a}' :experiment $in1_2"
echo "It is submitted to the pool with ${cores} cores." 
echo "Check the status with 'condor_q'"
(( in1_2 += 1 ))

done
fi

